# Studio Eien mascot icon assets

54 individual transparent PNGs cropped from the two supplied sheets. Original and refined versions are included. The source artwork is raster, so these are PNGs rather than vector SVGs.

Note: automated background removal may leave small edge artifacts. Inspect individual assets before production use.
